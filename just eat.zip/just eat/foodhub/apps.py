from django.apps import AppConfig


class FoodhubConfig(AppConfig):
    name = 'foodhub'
